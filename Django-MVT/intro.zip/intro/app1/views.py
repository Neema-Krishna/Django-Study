from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return HttpResponse('<h1>Hello! Welcome</h1>')
def home1(request):
    x='Helllo'
    return HttpResponse(x)
def home2(request):
    x=''
    y=[10,20,30]
    return render(request,'home.html',{'data':x,'data1':y})
def home_page(request):
    return render(request,'home_page.html')
def register(request):
    return render(request,'registration.html')
def log_in(request):
    return render(request,'login.html')




