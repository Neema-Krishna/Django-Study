from django.urls import path,include
from app1 import views

urlpatterns = [
    path('home',views.home,name='home'),
    path('home1/',views.home1,name='home1'),
    path('home2/',views.home2,name='home2'),
    path('',views.home_page,name='home_page'),
    path('register/',views.register,name='register'),
    path('login/',views.log_in,name='log_in')
]